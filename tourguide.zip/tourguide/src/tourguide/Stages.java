package tourguide;

import java.util.HashMap;

public class Stages {
    public int stage = 0;
    public String id;
    public String title;
    public int numWaypoints = 0;
    public int numLegs = 0;
    public Annotation annotation;
    public HashMap <Integer,Annotation> stageAndLeg = new HashMap <> ();
    public HashMap <Integer,Annotation> stageAndWaypoints = new HashMap <> ();
    
    public Stages (String id, String title, Annotation annotation ) {
        this.id = id;
        this.title = title;
        this.annotation = annotation;
    }
    
    // increase the number of stage.
    
    public void increaseStage () {
        this.stage++;
    }
    
    //add a waypoint annotation to corresponding stage.
    
    public void addWaypoint (Annotation waypoint) {
        this.numLegs++;
        stageAndWaypoints.put(stage, waypoint );
    }
    
    //add a leg annotation to corresponding stage.
    
    public void addLeg (Annotation leg) {
        this.numWaypoints++;
        stageAndLeg.put(stage, leg );
    }
    
}
