package tourguide;

public class Displacement2 {
    
    public double x1;
    public double y1;
    public double x2;
    public double y2;
    
    public Displacement2 (Displacement d1, Displacement d2) {
       this.x1 = d1.east;
       this.x2 = d2.east;
       this.y1 = d1.north;
       this.y2 = d2.north;
    }
    
    //calculate the distance between two locations (two Displacement objects).
    
    public double distance () {
        return Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    }
    
    //calculate the bearing of a location from another (of d2 from d1).
    
    public double bearing() {
        double inRadians = Math.atan2((x2-x1), (y2-y1));
        
        if (inRadians < 0) {
            inRadians = inRadians + 2 * Math.PI;
        }
        
        return Math.toDegrees(inRadians);
    }
}
