package tourguide;

import java.util.ArrayList;

public class ListLocation {
    private ArrayList <Displacement> locs = new ArrayList <> ();
    
    //store a list of locations in the form of ArrayList <Displacement>
    
    public ListLocation (ArrayList <Displacement> locs) {
        this.locs = locs;
    }
    
    //return the stored locations.
    
    public ArrayList <Displacement> out () {
        return this.locs;
    }
    
}
