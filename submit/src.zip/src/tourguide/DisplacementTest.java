/**
 * 
 */
package tourguide;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author pbj
 */
public class DisplacementTest {
    /**
     * EPS = Epsilon, the difference to allow in floating point numbers when 
     * comparing them for equality.
     */
    private static final double EPS = 0.01; 
    
    @Test
    public void testNorthBearing() {
        double bearing = new Displacement(0.0, 1.0).bearing();
        assertEquals(0.0, bearing, EPS);
    }
    
    @Test
    public void testBearing() {
        double Ebearing = new Displacement(1.0, 0.0).bearing();
        assertEquals(90.0,Ebearing,EPS); 
        double Sbearing = new Displacement(0.0,-1.0).bearing();
        assertEquals(180.0,Sbearing,EPS);
        double Wbearing = new Displacement(-1.0,0.0).bearing();
        assertEquals(270.0,Wbearing,EPS);
        double b1 = new Displacement (1.0,1.0).bearing();
        assertEquals(45.0,b1,EPS);
        double b2 = new Displacement (-1.0,-1.0).bearing();
        assertEquals(225.0,b2,EPS);
        double b3 = new Displacement (-1.0,1.0).bearing();
        assertEquals(315.0,b3,EPS);
        double b4 = new Displacement (5.2,3.4).bearing();
        assertEquals(56.82,b4,EPS);
        double b5 = new Displacement (-5.2,3.4).bearing();
        assertEquals(303.18,b5,EPS);
        double b6 = new Displacement (-5.2,-3.4).bearing();
        assertEquals(236.82,b6,EPS);
        double b7 = new Displacement (5.2,-3.4).bearing();
        assertEquals(123.18,b7,EPS);
    }

    @Test
    public void testDistance() {
        double distance = new Displacement(0.0,0.0).distance();
        assertEquals(0,distance,0.0);
        double d1 = new Displacement(1.0,1.0).distance();
        assertEquals(1.41,d1,EPS);
        double d11 = new Displacement(-1.0,1.0).distance();
        assertEquals(1.41,d11,EPS);
        double d12 = new Displacement(-1.0,-1.0).distance();
        assertEquals(1.41,d12,EPS);
        double d13 = new Displacement(1.0,-1.0).distance();
        assertEquals(1.41,d13,EPS);
        double d2 = new Displacement (10.3,2.4).distance();
        assertEquals(10.58,d2,EPS);
        double d21 = new Displacement (-10.3,-2.4).distance();
        assertEquals(10.58,d21,EPS);
        double d22 = new Displacement (10.3,-2.4).distance();
        assertEquals(10.58,d22,EPS);
        double d23 = new Displacement (-10.3,2.4).distance();
        assertEquals(10.58,d23,EPS);
        
    }
    

    
 
}
