/**
 * 
 */
package tourguide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

/**
 * @author pbj
 */
public class ControllerImp implements Controller {
    private static Logger logger = Logger.getLogger("tourguide");
    private static final String LS = System.lineSeparator();

    private String startBanner(String messageName) {
        return LS + "-------------------------------------------------------------" + LS + "MESSAGE: " + messageName
                + LS + "-------------------------------------------------------------";
    }

    // createHeader is output for create mode; browseOverviews is output for overview browse mode;
    // browseDetails is output for detail browse mode;
    // followTour is output for follow mode;
    private ArrayList<Chunk> createHeader = new ArrayList<>();
    private ArrayList<Chunk> browseOverviews = new ArrayList<>();
    private ArrayList<Chunk> browseDetails = new ArrayList<>();
    private ArrayList<Chunk> followTour = new ArrayList<>();
    private double waypointRadius;
    private double waypointSeparation;
    private double mode;

    public ControllerImp(double waypointRadius, double waypointSeparation) {
        this.waypointRadius = waypointRadius;
        this.waypointSeparation = waypointSeparation;
        // mode 1 = browse mode ; mode 1.1 = detail browse mode;
        // mode 2 = create mode
        // mode 3 = follow mode
        this.mode = 1;
    }

    // --------------------------
    // Create tour mode
    // --------------------------

    // Some examples are shown below of use of logger calls. The rest of the methods
    // below that correspond
    // to input messages could do with similar calls.

    private Stages stage;
    private HashMap<String, Stages> tourlist = new HashMap<>();
    // createheader for create mode chunk, browseoverview for overall browse chunk... and so on as above.
    private Chunk createheader;
    private Chunk.BrowseOverview browseoverview = new Chunk.BrowseOverview();
    private HashMap<String, Chunk> browsedetail = new HashMap<>();
    private String title;
    private String id;
    private Annotation annotation;
    private ArrayList<Displacement> loc = new ArrayList<>(); // list of locations.
    private int numLegs;
    private int numWaypoints;
    private HashMap<String, ListLocation> locations = new HashMap<>(); // mapping tour id with list of locations of waypoints.
    private double easting;
    private double northing;
    private int curStage = 0; // used in follow tour, indicating which current stage is.
    private String followId;

    @Override
    public Status startNewTour(String id, String title, Annotation annotation) {
        logger.fine(startBanner("startNewTour"));
        if (this.mode != 1 && this.mode != 1.1) {
            return new Status.Error("not in browse mode");
        }
        if (this.tourlist.containsKey(id)) {
            return new Status.Error("already had this tour");
        }
        this.mode = 2;   // set mode to create mode.
        this.title = title;
        this.id = id;
        this.annotation = annotation;
        this.numLegs = 0;
        this.numWaypoints = 0;
        if (!this.createHeader.isEmpty()) {
            this.createHeader.remove(0);
        }
        this.stage = new Stages(id, title, annotation);  
        this.createheader = new Chunk.CreateHeader(this.title, this.numLegs, this.numWaypoints);
        createHeader.add(0, createheader);
        return Status.OK;
    }

    @Override
    public Status addWaypoint(Annotation annotation) {
        logger.fine(startBanner("addWaypoint"));
        if (this.mode != 2 && this.mode != 2.1 && this.mode != 2.2)
            return new Status.Error("a leg needed to be added before a waypoint");
        if (this.mode == 2 || this.mode == 2.2) {
            if (loc.size() > 0) {
                if (new Displacement2((new Displacement(this.easting, this.northing)), (loc.get(loc.size() - 1)))
                        .distance() < this.waypointSeparation) {
                    return new Status.Error("two waypoints are too close");
                }
            }
            this.mode = 2.2;  // mode =2.2 indicating the last action taken is adding a waypoint.
            stage.addLeg(Annotation.DEFAULT);
            stage.increaseStage();
            stage.addWaypoint(annotation);
            this.numLegs++;
            this.numWaypoints++;
            this.createheader = new Chunk.CreateHeader(this.title, this.numLegs, this.numWaypoints);
            createHeader.remove(0);
            createHeader.add(0, createheader);
            this.loc.add(new Displacement(this.easting, this.northing));
            return Status.OK;
        }
        if (loc.size() > 0) {
            if (new Displacement2((new Displacement(easting, northing)), (loc.get(loc.size() - 1)))
                    .distance() < this.waypointSeparation) {
                return new Status.Error("two waypoints are too close");
            }
        }
        this.mode = 2.2;
        stage.increaseStage();
        stage.addWaypoint(annotation);
        this.numWaypoints++;
        this.createheader = new Chunk.CreateHeader(this.title, this.numLegs, this.numWaypoints);
        createHeader.remove(0);
        createHeader.add(0, createheader);
        this.loc.add(new Displacement(easting, northing));
        return Status.OK;
    }

    @Override
    public Status addLeg(Annotation annotation) {
        logger.fine(startBanner("addLeg"));
        if (this.mode != 2 && this.mode != 2.2) {
            return new Status.Error("can't add the leg");
        }
        this.mode = 2.1;  // mode = 2.1 indicating last action taken is adding a leg.
        stage.addLeg(annotation);
        this.numLegs++;
        this.createheader = new Chunk.CreateHeader(this.title, this.numLegs, this.numWaypoints);
        createHeader.remove(0);
        createHeader.add(0, createheader);
        return Status.OK;
    }

    @Override
    public Status endNewTour() {
        logger.fine(startBanner("endNewTour"));
        if (this.mode == 1.0) {
            return Status.OK;
        }
        if (this.mode != 2.2) {
            return new Status.Error("can't end the new tour");
        }
        this.mode = 1;   //set mode back to create mode.
        tourlist.put(stage.id, stage);  // add created tour into tourlist.
        this.browseoverview.addIdAndTitle(this.id, this.title);
        this.browsedetail.put(id, new Chunk.BrowseDetails(id, title, annotation));
        ArrayList<Displacement> loc1 = new ArrayList<>();
        for (int i = 0; i < this.loc.size(); i++) {
            loc1.add(this.loc.get(i));
        }
        this.locations.put(this.id, new ListLocation(loc1));
        this.loc.clear();
        return Status.OK;
    }

    // --------------------------
    // Browse tours mode
    // --------------------------

    @Override
    public Status showTourDetails(String tourID) {
        logger.fine(startBanner("showTourDetails"));
        if ((this.mode != 1 && this.mode != 1.1) || !this.browsedetail.containsKey(tourID))
            return new Status.Error("can't show details");
        this.mode = 1.1;  // mode = 1.1 is detail browse mode.
        this.browseDetails.clear();
        this.browseDetails.add(this.browsedetail.get(tourID));
        return Status.OK;
    }

    @Override
    public Status showToursOverview() {
        logger.fine(startBanner("showToursOverview"));
        if (this.mode != 1 && this.mode != 1.1)
            return new Status.Error("can't show overview");
        this.mode = 1; // set mode to browse overview mode.
        return Status.OK;
    }

    // --------------------------
    // Follow tour mode
    // --------------------------

    @Override
    public Status followTour(String id) {
        logger.fine(startBanner("followTour"));
        if ((this.mode != 1 && this.mode != 1.1) || !tourlist.containsKey(id)) {
            return new Status.Error("can't follow the tour");
        }
        this.mode = 3; //set mode to follow mode.
        this.curStage = 0;  
        this.followId = id;
        return Status.OK;

    }

    @Override
    public Status endSelectedTour() {
        logger.fine(startBanner("endSelectedTour"));
        if (this.mode != 3) {
            return new Status.Error("unimplemented");
        }
        this.followTour.clear();
        this.mode = 1; // set mode back to browse overview mode.
        return Status.OK;
    }

    // --------------------------
    // Multi-mode methods
    // --------------------------
    @Override
    public void setLocation(double easting, double northing) {
        logger.fine(startBanner("setLocation" + " " + easting + ", " + northing));
        this.easting = easting;  //set location
        this.northing = northing;
        // if mode is follow mode, it update the output chunk.
        if (mode == 3) {
            this.followTour.clear();
            Displacement d1 = new Displacement(this.easting, this.northing);
            if (new Displacement2(d1, this.locations.get(followId).out().get(curStage))
                    .distance() <= this.waypointRadius) { // testing if the point is in the aiming waypoint range.
                this.curStage++;
                if (curStage == tourlist.get(followId).stage) {//the case if the waypoint is the last one.
                    this.followTour.add(new Chunk.FollowHeader(tourlist.get(followId).title, this.curStage,
                            tourlist.get(followId).numWaypoints));
                    this.followTour
                            .add(new Chunk.FollowWaypoint(tourlist.get(followId).stageAndWaypoints.get(curStage)));

                } else {//case if the waypoint is not the last one.
                    this.followTour.add(new Chunk.FollowHeader(tourlist.get(followId).title, this.curStage,
                            tourlist.get(followId).numWaypoints));
                    this.followTour
                            .add(new Chunk.FollowWaypoint(tourlist.get(followId).stageAndWaypoints.get(curStage)));
                    this.followTour.add(new Chunk.FollowLeg(tourlist.get(followId).stageAndLeg.get(curStage)));
                    this.followTour.add(new Chunk.FollowBearing(
                            new Displacement2(d1, locations.get(followId).out().get(curStage)).bearing(),
                            new Displacement2(d1, locations.get(followId).out().get(curStage)).distance()));

                }
            } else {
                if (curStage > 0) {// case if it has already arrived at least a waypoint.
                    if (new Displacement2(d1, this.locations.get(followId).out().get(curStage - 1))
                            .distance() <= this.waypointRadius) {
                        this.followTour.add(new Chunk.FollowHeader(tourlist.get(followId).title, this.curStage,
                                tourlist.get(followId).numWaypoints));
                        this.followTour.add(
                                new Chunk.FollowWaypoint(tourlist.get(followId).stageAndWaypoints.get(curStage)));
                        this.followTour.add(new Chunk.FollowLeg(tourlist.get(followId).stageAndLeg.get(curStage)));
                        this.followTour.add(new Chunk.FollowBearing(
                                new Displacement2(d1, locations.get(followId).out().get(curStage)).bearing(),
                                new Displacement2(d1, locations.get(followId).out().get(curStage)).distance()));
                    }
                    else {
                        this.followTour.add(new Chunk.FollowHeader(tourlist.get(followId).title, this.curStage,
                                tourlist.get(followId).numWaypoints));
                        this.followTour.add(new Chunk.FollowLeg(tourlist.get(followId).stageAndLeg.get(curStage)));
                        this.followTour.add(new Chunk.FollowBearing(
                                new Displacement2(d1, locations.get(followId).out().get(curStage)).bearing(),
                                new Displacement2(d1, locations.get(followId).out().get(curStage)).distance()));
                    }
                }
                else {//case only when curStage = 0
                    this.followTour.add(new Chunk.FollowHeader(tourlist.get(followId).title, this.curStage,
                            tourlist.get(followId).numWaypoints));
                    this.followTour.add(new Chunk.FollowLeg(tourlist.get(followId).stageAndLeg.get(curStage)));
                    this.followTour.add(new Chunk.FollowBearing(
                            new Displacement2(d1, locations.get(followId).out().get(curStage)).bearing(),
                            new Displacement2(d1, locations.get(followId).out().get(curStage)).distance()));
                }
            }
        }
    }

    @Override
    public List<Chunk> getOutput() {
        logger.fine(startBanner("getOutput"));
        //get output depends on current mode;
        if (mode == 1) {
            this.browseOverviews.clear();
            this.browseOverviews.add(browseoverview);
            return this.browseOverviews;
        }
        if (mode == 1.1) {
            return this.browseDetails;
        }
        if (mode >= 2 && mode < 3) {
            return this.createHeader;
        }
        if (mode == 3) {
            return this.followTour;
        }
        return new ArrayList<>();

    }

}
